package dev.egoist.client.hud;

/** HUD registration is temporarily disabled pending the 26.2 GUI-layer API. */
public final class EgoistHud {
    private EgoistHud() {}
    public static void init() {}
}

package dev.egoist.client.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class NumberSetting extends Setting<Double> {
    private final double min, max, step;
    public NumberSetting(String id, String label, double value, double min, double max, double step) {
        super(id, label, value);
        if (!Double.isFinite(min) || !Double.isFinite(max) || min > max || step <= 0 || !Double.isFinite(step)) throw new IllegalArgumentException("Invalid number setting range");
        this.min=min; this.max=max; this.step=step;
        set(value);
    }
    public double min() { return min; } public double max() { return max; } public double step() { return step; }
    @Override protected Double validate(Double value) { if (value == null || !Double.isFinite(value)) throw new IllegalArgumentException("Number setting must be finite"); return Math.max(min, Math.min(max, value)); }
    @Override public JsonElement toJson() { return new JsonPrimitive(value()); }
    @Override public void fromJson(JsonElement element) { if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) { try { set(element.getAsDouble()); } catch (RuntimeException ignored) { reset(); } } }
}

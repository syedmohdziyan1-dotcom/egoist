package dev.egoist.client.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String id, String label, boolean defaultValue) { super(id, label, defaultValue); }
    @Override protected Boolean validate(Boolean value) { if (value == null) throw new IllegalArgumentException("Boolean setting cannot be null"); return value; }
    @Override public JsonElement toJson() { return new JsonPrimitive(value()); }
    @Override public void fromJson(JsonElement element) { if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isBoolean()) set(element.getAsBoolean()); }
}

package dev.egoist.client.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** A typed, validated setting owned by a client module. */
public abstract class Setting<T> {
    private final String id;
    private final String label;
    private final T defaultValue;
    private T value;

    protected Setting(String id, String label, T defaultValue) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Setting id cannot be blank");
        this.id = id;
        this.label = label == null ? id : label;
        this.defaultValue = validate(defaultValue);
        this.value = this.defaultValue;
    }
    public final String id() { return id; }
    public final String label() { return label; }
    public final T defaultValue() { return defaultValue; }
    public final T value() { return value; }
    public final void set(T value) { this.value = validate(value); }
    public final void reset() { value = defaultValue; }
    protected abstract T validate(T value);
    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement element);
}

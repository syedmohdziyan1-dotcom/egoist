package dev.egoist.client.gui;

import dev.egoist.client.config.ConfigManager;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.module.ModuleRegistry;
import dev.egoist.client.settings.BooleanSetting;
import dev.egoist.client.settings.NumberSetting;
import dev.egoist.client.settings.Setting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.List;

/** EGOIST's custom, draggable, violet-themed module/settings screen. */
public final class EgoistScreen extends Screen {
    private static final List<String> CATEGORIES = List.of("Combat", "Crystal", "Movement", "Visuals", "Misc", "Chat", "Automation");
    private static final int PANEL_W = 430, PANEL_H = 300, SIDEBAR_W = 118, HEADER_H = 36;
    private static final int BG = 0xF20B0913, PANEL = 0xE9161222, PANEL_ALT = 0xFF21182F, PURPLE = 0xFF8D36FF, PURPLE_SOFT = 0xFFB68AFF;
    private String selected = "Visuals";
    private int panelX, panelY, scroll;
    private boolean dragging, binding;
    private double dragOffsetX, dragOffsetY;
    private ClientModule bindModule;
    private ClientModule selectedModule;
    private float animationPhase;

    public EgoistScreen() { super(Component.literal("EGOIST CLIENT")); }
    @Override protected void init() {
        panelX = Math.max(8, (width - PANEL_W) / 2);
        panelY = Math.max(8, (height - PANEL_H) / 2);
    }

    @Override public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        animationPhase += delta;
        g.fill(0, 0, width, height, 0x66000000);
        g.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, BG);
        g.fill(panelX, panelY, panelX + PANEL_W, panelY + 3, PURPLE);
        int accentSweep = 90 + (int)(45.0 * (0.5 + 0.5 * Math.sin(animationPhase * 0.08)));
        g.fill(panelX + 3, panelY + 3, panelX + Math.min(PANEL_W - 3, accentSweep), panelY + 4, PURPLE_SOFT);
        g.fill(panelX, panelY + HEADER_H, panelX + SIDEBAR_W, panelY + PANEL_H, PANEL);
        g.fill(panelX + SIDEBAR_W, panelY + HEADER_H, panelX + PANEL_W, panelY + PANEL_H, 0xE90F0C18);
        g.text(font, "EGOIST", panelX + 14, panelY + 12, 0xFFF2E9FF, true);
        g.text(font, "CLIENT  /  26.2", panelX + 74, panelY + 13, PURPLE_SOFT, false);
        g.text(font, "X", panelX + PANEL_W - 18, panelY + 13, 0xFFBFAED5, false);
        for (int i = 0; i < CATEGORIES.size(); i++) {
            int y = panelY + HEADER_H + 9 + i * 29;
            boolean active = selected.equals(CATEGORIES.get(i));
            if (active) { g.fill(panelX + 7, y - 3, panelX + SIDEBAR_W - 7, y + 21, 0xFF332044); g.fill(panelX + 7, y - 3, panelX + 10, y + 21, PURPLE); }
            g.text(font, CATEGORIES.get(i), panelX + 17, y + 3, active ? 0xFFE8D6FF : 0xFFAAA0B9, active);
        }
        g.text(font, "DRAG HEADER  •  RIGHT SHIFT", panelX + 12, panelY + PANEL_H - 18, 0xFF84778E, false);
        List<ClientModule> modules = ModuleRegistry.category(selected);
        int listX = panelX + SIDEBAR_W + 16, listY = panelY + HEADER_H + 12;
        g.text(font, selected.toUpperCase() + "  /  " + modules.size() + " MODULES", listX, listY, PURPLE_SOFT, true);
        if (modules.isEmpty()) g.text(font, "No modules in this category yet.", listX + 8, listY + 32, 0xFF8D819B, false);
        int rowY = listY + 21;
        for (int i = scroll; i < modules.size() && i < scroll + 8; i++) {
            ClientModule module = modules.get(i);
            int y = rowY + (i - scroll) * 30;
            g.fill(listX, y, panelX + PANEL_W - 12, y + 25, module.enabled() ? 0xFF281A39 : PANEL_ALT);
            g.text(font, module.name(), listX + 8, y + 8, module.enabled() ? 0xFFF0E5FF : 0xFFD0C3DD, module.enabled());
            g.text(font, module.enabled() ? "ON" : "OFF", panelX + PANEL_W - 45, y + 8, module.enabled() ? PURPLE_SOFT : 0xFF80738D, true);
            String desc = module.description();
            if (desc != null && !desc.isBlank()) g.text(font, truncate(desc, 36), listX + 8, y + 18, 0xFF887A98, false);
        }
        // Settings for the selected category are rendered in the right-side editor region below modules.
        ClientModule expanded = selectedModule != null && selectedModule.category().equalsIgnoreCase(selected) ? selectedModule : null;
        if (expanded != null && !expanded.settings().isEmpty()) renderSettings(g, expanded, listX, panelY + PANEL_H - 96);
        g.fill(panelX + PANEL_W - 90, panelY + PANEL_H - 26, panelX + PANEL_W - 12, panelY + PANEL_H - 8, 0xFF261B36);
        g.text(font, "SAVE PROFILE", panelX + 12, panelY + PANEL_H - 20, PURPLE_SOFT, false);
        g.text(font, "LOAD PROFILE", panelX + 94, panelY + PANEL_H - 20, PURPLE_SOFT, false);
        g.text(font, binding ? "PRESS KEY..." : "DEFAULT", panelX + PANEL_W - 82, panelY + PANEL_H - 20, PURPLE_SOFT, false);
    }

    private void renderSettings(GuiGraphicsExtractor g, ClientModule module, int x, int y) {
        if (module.settings().isEmpty()) return;
        int available = Math.max(0, module.settings().size());
        int start = Math.max(0, available - 3);
        g.fill(x, y - 5, panelX + PANEL_W - 12, panelY + PANEL_H - 32, 0xFF100D18);
        g.text(font, module.name().toUpperCase() + " SETTINGS", x + 5, y, PURPLE_SOFT, true);
        int line = 15;
        for (int i = start; i < available; i++) {
            Setting<?> setting = module.settings().get(i);
            int sy = y + line;
            g.text(font, setting.label(), x + 5, sy, 0xFFD5C8E5, false);
            if (setting instanceof BooleanSetting b) {
                g.text(font, b.value() ? "[ ON ]" : "[ OFF ]", panelX + PANEL_W - 68, sy, b.value() ? PURPLE_SOFT : 0xFF887A98, true);
            } else if (setting instanceof NumberSetting n) {
                g.text(font, format(n.value()) + "  <  >", panelX + PANEL_W - 102, sy, PURPLE_SOFT, false);
            } else {
                g.text(font, "(setting)", panelX + PANEL_W - 70, sy, 0xFF887A98, false);
            }
            line += 15;
        }
        g.text(font, "KEY: " + keyName(module.keybind()) + "  [click to bind]", x + 5, panelY + PANEL_H - 39, 0xFFB8A6D0, false);
    }

    private ClientModule hoveredModule(int mx, int my, List<ClientModule> modules, int listX, int listY) {
        if (mx < listX || mx > panelX + PANEL_W - 12 || my < listY || my > listY + 8 * 30) return null;
        int index = scroll + (my - listY) / 30;
        return index >= 0 && index < modules.size() ? modules.get(index) : null;
    }

    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y(); int button = event.button();
        if (button != GLFW.GLFW_MOUSE_BUTTON_1) return super.mouseClicked(event, doubleClick);
        if (mx >= panelX + 8 && mx <= panelX + 85 && my >= panelY + PANEL_H - 28 && my <= panelY + PANEL_H - 7) { ConfigManager.saveProfile("default"); return true; }
        if (mx >= panelX + 90 && mx <= panelX + 165 && my >= panelY + PANEL_H - 28 && my <= panelY + PANEL_H - 7) { ConfigManager.loadProfile("default"); return true; }
        if (mx >= panelX && mx <= panelX + PANEL_W && my >= panelY && my <= panelY + HEADER_H) {
            if (mx > panelX + PANEL_W - 28) { onClose(); return true; }
            dragging = true; dragOffsetX = mx - panelX; dragOffsetY = my - panelY; return true;
        }
        for (int i = 0; i < CATEGORIES.size(); i++) {
            int y = panelY + HEADER_H + 9 + i * 29;
            if (mx >= panelX + 7 && mx <= panelX + SIDEBAR_W - 7 && my >= y - 3 && my <= y + 21) { selected = CATEGORIES.get(i); scroll = 0; return true; }
        }
        List<ClientModule> modules = ModuleRegistry.category(selected);
        int listX = panelX + SIDEBAR_W + 16, listY = panelY + HEADER_H + 33;
        ClientModule editor = selectedModule != null && selectedModule.category().equalsIgnoreCase(selected) ? selectedModule : null;
        if (editor != null && my >= panelY + PANEL_H - 96 && my <= panelY + PANEL_H - 32) {
            if (my >= panelY + PANEL_H - 43) { binding = true; bindModule = editor; return true; }
            int settingIndex = (int)((my - (panelY + PANEL_H - 81)) / 15);
            int start = Math.max(0, editor.settings().size() - 3);
            settingIndex += start;
            if (settingIndex >= 0 && settingIndex < editor.settings().size()) {
                Setting<?> setting = editor.settings().get(settingIndex);
                if (setting instanceof BooleanSetting b) b.set(!b.value());
                else if (setting instanceof NumberSetting n) n.set(n.value() + (mx >= panelX + PANEL_W - 108 ? n.step() : -n.step()));
                ConfigManager.save(); return true;
            }
        }
        ClientModule module = hoveredModule((int)mx, (int)my, modules, listX, listY);
        if (module != null) {
            int row = (int)((my - listY) / 30);
            int moduleY = listY + row * 30;
            if (my <= moduleY + 25) {
                if (mx > panelX + PANEL_W - 56) module.toggle();
                selectedModule = module;
                ConfigManager.save(); return true;
            }
        }
        return true;
    }

    private void editSetting(ClientModule module, double mx) {
        int right = panelX + PANEL_W - 108;
        for (Setting<?> s : module.settings()) {
            if (s instanceof BooleanSetting b) b.set(!b.value());
            else if (s instanceof NumberSetting n) n.set(n.value() + (mx >= right ? n.step() : -n.step()));
        }
        ConfigManager.save();
    }

    @Override public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging && event.button() == GLFW.GLFW_MOUSE_BUTTON_1) { panelX = clamp(panelX + (int)dx, 4, width - PANEL_W - 4); panelY = clamp(panelY + (int)dy, 4, height - PANEL_H - 4); return true; }
        return super.mouseDragged(event, dx, dy);
    }
    @Override public boolean mouseReleased(MouseButtonEvent event) { if (event.button() == GLFW.GLFW_MOUSE_BUTTON_1) dragging = false; return super.mouseReleased(event); }
    @Override public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) { scroll = clamp(scroll + (deltaY < 0 ? 1 : -1), 0, Math.max(0, ModuleRegistry.category(selected).size() - 1)); return true; }
    @Override public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (binding && bindModule != null) { bindModule.keybind(key == GLFW.GLFW_KEY_ESCAPE ? 0 : key); binding = false; bindModule = null; ConfigManager.save(); return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(event);
    }
    @Override public void onClose() { ConfigManager.save(); super.onClose(); }
    @Override public boolean isPauseScreen() { return false; }
    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private static String truncate(String s, int length) { return s.length() <= length ? s : s.substring(0, length - 1) + "…"; }
    private static String format(double d) { return String.format(java.util.Locale.ROOT, "%.2f", d); }
    private static String keyName(int key) { return key == 0 ? "NONE" : GLFW.glfwGetKeyName(key, 0) != null ? GLFW.glfwGetKeyName(key, 0) : "KEY " + key; }
}

package dev.egoist.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.module.ModuleRegistry;
import dev.egoist.client.settings.Setting;
import net.minecraft.client.Minecraft;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Saves configuration atomically to .minecraft/config/egoist.json. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path file;
    private static Path profilesDirectory;
    private ConfigManager() {}
    public static void init(Minecraft client) {
        Path configDir = client.gameDirectory.toPath().resolve("config");
        file = configDir.resolve("egoist.json");
        profilesDirectory = configDir.resolve("egoist-profiles");
        load();
    }
    public static Path file() { return file; }
    public static void saveProfile(String name) { saveTo(profilePath(name)); }
    public static void loadProfile(String name) { loadFrom(profilePath(name)); }
    private static Path profilePath(String name) {
        String safe = name == null ? "default" : name.replaceAll("[^A-Za-z0-9_-]", "_");
        if (safe.isBlank()) safe = "default";
        return profilesDirectory.resolve(safe + ".json");
    }
    public static void save() { saveTo(file); }
    private static void saveTo(Path target) {
        if (target == null) return;
        JsonObject root = new JsonObject();
        root.addProperty("version", 1);
        JsonObject modules = new JsonObject();
        for (ClientModule module : ModuleRegistry.all()) {
            JsonObject m = new JsonObject();
            m.addProperty("enabled", module.enabled()); m.addProperty("keybind", module.keybind());
            JsonObject settings = new JsonObject();
            for (Setting<?> setting : module.settings()) settings.add(setting.id(), setting.toJson());
            m.add("settings", settings); modules.add(module.id(), m);
        }
        root.add("modules", modules);
        try {
            Files.createDirectories(target.getParent());
            Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.writeString(tmp, GSON.toJson(root), StandardCharsets.UTF_8);
            try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException atomicUnsupported) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { System.err.println("[Egoist] Config save failed: " + e.getMessage()); }
    }
    public static void load() { loadFrom(file); }
    private static void loadFrom(Path source) {
        if (source == null || !Files.isRegularFile(source)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(source, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject modules = root.has("modules") && root.get("modules").isJsonObject() ? root.getAsJsonObject("modules") : new JsonObject();
            for (ClientModule module : ModuleRegistry.all()) {
                if (!modules.has(module.id()) || !modules.get(module.id()).isJsonObject()) continue;
                JsonObject m = modules.getAsJsonObject(module.id());
                if (m.has("keybind") && m.get("keybind").isJsonPrimitive()) try { module.keybind(m.get("keybind").getAsInt()); } catch (RuntimeException ignored) {}
                JsonObject settings = m.has("settings") && m.get("settings").isJsonObject() ? m.getAsJsonObject("settings") : new JsonObject();
                for (Setting<?> setting : module.settings()) if (settings.has(setting.id())) setting.fromJson(settings.get(setting.id()));
                if (m.has("enabled") && m.get("enabled").isJsonPrimitive()) try { module.setEnabled(m.get("enabled").getAsBoolean()); } catch (RuntimeException ignored) { module.setEnabled(false); }
            }
        } catch (Exception e) { System.err.println("[Egoist] Config load failed; using defaults: " + e.getMessage()); }
    }
}

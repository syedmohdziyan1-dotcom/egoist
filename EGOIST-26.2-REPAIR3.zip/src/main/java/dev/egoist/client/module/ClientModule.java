package dev.egoist.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import dev.egoist.client.settings.Setting;
import net.minecraft.client.Minecraft;

/** Base class with a small lifecycle and settings list. */
public class ClientModule {
    private final String id, name, category, description;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int keybind;

    public ClientModule(String id, String name, String category, String description) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Module id cannot be blank");
        this.id=id; this.name=name; this.category=category; this.description=description;
    }
    public final String id() { return id; } public final String name() { return name; }
    public final String category() { return category; } public final String description() { return description; }
    public final boolean enabled() { return enabled; } public final int keybind() { return keybind; }
    public final void keybind(int key) { keybind=key; }
    public final List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    protected final <S extends Setting<?>> S addSetting(S setting) { settings.add(setting); return setting; }
    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        try { if (value) onEnable(); else onDisable(); }
        catch (RuntimeException exception) { enabled=false; try { onDisable(); } catch (RuntimeException ignored) {} throw exception; }
    }
    public final void toggle() { setEnabled(!enabled); }
    protected void onEnable() {} protected void onDisable() {}
    public void tick(Minecraft client) {}
}

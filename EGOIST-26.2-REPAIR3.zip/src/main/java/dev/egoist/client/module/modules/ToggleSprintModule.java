package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
import net.minecraft.client.Minecraft;
public final class ToggleSprintModule extends ClientModule {
    private final BooleanSetting whileMoving = addSetting(new BooleanSetting("while_moving", "Only while moving", true));
    public ToggleSprintModule() { super("toggle_sprint", "Toggle Sprint", "Movement", "Client-side sprint helper"); }
    @Override public void tick(Minecraft client) {
        if (client.player == null) return;
        if (!whileMoving.value() || client.player.input.hasForwardImpulse()) client.player.setSprinting(true);
    }
}

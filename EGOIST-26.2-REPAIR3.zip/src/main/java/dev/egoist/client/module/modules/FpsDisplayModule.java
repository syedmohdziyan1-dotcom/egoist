package dev.egoist.client.module.modules;

import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
import dev.egoist.client.settings.NumberSetting;

/** Configurable FPS overlay. */
public final class FpsDisplayModule extends ClientModule {
    public final BooleanSetting showInDebug = addSetting(new BooleanSetting("show_in_debug", "Show with debug screen", false));
    public final BooleanSetting showLabel = addSetting(new BooleanSetting("show_label", "Show FPS label", true));
    public final NumberSetting x = addSetting(new NumberSetting("x", "Horizontal position", 6, 0, 1000, 1));
    public final NumberSetting y = addSetting(new NumberSetting("y", "Vertical position", 6, 0, 1000, 1));
    public FpsDisplayModule() { super("fps_display", "FPS Display", "Visuals", "Displays the current frame rate"); }
}

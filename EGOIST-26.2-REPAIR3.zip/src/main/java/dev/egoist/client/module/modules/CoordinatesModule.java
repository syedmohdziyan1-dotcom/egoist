package dev.egoist.client.module.modules;

import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
import dev.egoist.client.settings.NumberSetting;

/** Configurable coordinates and dimension overlay. */
public final class CoordinatesModule extends ClientModule {
    public final BooleanSetting showDimension = addSetting(new BooleanSetting("show_dimension", "Show dimension", true));
    public final BooleanSetting showFacing = addSetting(new BooleanSetting("show_facing", "Show facing", false));
    public final NumberSetting x = addSetting(new NumberSetting("x", "Horizontal position", 6, 0, 1000, 1));
    public final NumberSetting y = addSetting(new NumberSetting("y", "Vertical position", 24, 0, 1000, 1));
    public CoordinatesModule() { super("coordinates", "Coordinates", "Visuals", "Displays player coordinates and optional dimension"); }
}

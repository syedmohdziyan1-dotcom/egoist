# EGOIST Client 26.2 — module rebuild

Fabric client-side mod project. Open the GUI with **Right Shift**.

## Implemented module framework

Modules are registered in `ModuleRegistry`, expose typed settings, support per-module keybinds, tick hooks, enable/disable lifecycle, and persist enabled state, keybinds and settings in `config/egoist.json`. The default profile is saved in `config/egoist-profiles/default.json`.

Included modules:

- **Movement:** Toggle Sprint (client-side sprint helper)
- **Visuals:** FPS Display, Coordinates, Direction, Clock, Fullbright preference, Zoom settings
- **Player:** Player Info preferences
- **World:** World Info preferences
- **Misc:** Chat Timestamp preferences
- **GUI:** GUI Options and Interface options

The Combat and Crystal categories are reserved in the GUI. This build does not include automated combat, player-targeting, crystal automation, anti-cheat bypass, or other gameplay exploit modules.

## Build

The included GitHub Actions workflow builds the project when a project ZIP is pushed to the repository. The artifact is emitted by Gradle under `build/libs`.

## Important implementation status

This is a source rebuild, not a claim that every visible mockup item is implemented. The existing 26.2 HUD renderer was disabled after the earlier `HudElementRegistry` API compile failure. FPS/coordinates module settings and registry entries are present, but live in-game HUD drawing still needs the correct 26.2 rendering hook. Fullbright, zoom, chat timestamp, and some player/world display entries are configuration modules rather than active game hooks. The GUI and module list should not be described as feature-complete until those hooks are implemented and tested against the target Fabric API.

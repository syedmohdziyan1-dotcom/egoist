package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
/** Toggles the player's built-in information display options. */
public final class PlayerInfoModule extends ClientModule {
    public final BooleanSetting showHealth = addSetting(new BooleanSetting("show_health", "Show health in status panel", true));
    public final BooleanSetting showFood = addSetting(new BooleanSetting("show_food", "Show hunger in status panel", true));
    public PlayerInfoModule() { super("player_info", "Player Info", "Player", "Player status display preferences"); }
}

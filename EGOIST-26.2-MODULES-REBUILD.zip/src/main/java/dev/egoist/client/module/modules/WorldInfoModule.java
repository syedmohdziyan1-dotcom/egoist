package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
/** World and environment information preferences. */
public final class WorldInfoModule extends ClientModule {
    public final BooleanSetting showBiome = addSetting(new BooleanSetting("show_biome", "Show biome name", true));
    public final BooleanSetting showTime = addSetting(new BooleanSetting("show_time", "Show world time", true));
    public WorldInfoModule() { super("world_info", "World Info", "World", "World and environment information preferences"); }
}

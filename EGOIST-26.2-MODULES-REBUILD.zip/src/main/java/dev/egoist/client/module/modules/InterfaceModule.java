package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
import dev.egoist.client.settings.NumberSetting;
public final class InterfaceModule extends ClientModule {
    public final BooleanSetting showEnabledList = addSetting(new BooleanSetting("enabled_list", "Show enabled module list", true));
    public final BooleanSetting showWatermark = addSetting(new BooleanSetting("watermark", "Show EGOIST watermark", true));
    public final NumberSetting opacity = addSetting(new NumberSetting("opacity", "Panel opacity", 0.92, 0.35, 1.0, 0.01));
    public InterfaceModule() { super("interface", "Interface", "GUI", "Client interface appearance options"); }
}

package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.NumberSetting;
/** Configuration holder for the optional zoom feature; no input is intercepted by default. */
public final class ZoomModule extends ClientModule {
    public final NumberSetting zoomFactor = addSetting(new NumberSetting("zoom_factor", "Zoom factor", 4.0, 2.0, 12.0, 0.5));
    public ZoomModule() { super("zoom", "Zoom Settings", "Visuals", "Configurable zoom preference"); }
}

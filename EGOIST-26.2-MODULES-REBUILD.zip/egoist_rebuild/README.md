# EGOIST Client 26.2 — source rebuild

A Fabric client-side mod source package with a custom violet click GUI, category/module registry, setting controls, keybind support and JSON config/profile persistence.

## Implemented in this source
- Custom click GUI with draggable main panel, categories and module toggle rows
- Module registry, enable/disable lifecycle, keybind toggles and settings model
- Config save/load and profile file support
- Toggle Sprint client helper
- FPS Display and Coordinates module configuration models
- Fullbright, Direction, Clock, Armor Status, Chat Timestamp and GUI-options module entries/settings

## Important limitations
Several entries are currently module/configuration scaffolding, not finished rendering or gameplay hooks. The HUD renderer is not connected, so FPS/coordinates/armor/direction/clock overlays are not yet displayed in-game. Fullbright is not yet wired to gamma. This source does not implement automated combat, exploit or anti-cheat-evasion modules.

## Build
Upload the ZIP to the repository root and run the existing GitHub Actions workflow. Test the resulting JAR in a separate Minecraft instance before using it in a main installation.

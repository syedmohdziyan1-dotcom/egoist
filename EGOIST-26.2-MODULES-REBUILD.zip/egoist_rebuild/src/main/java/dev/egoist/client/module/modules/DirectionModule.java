package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
public final class DirectionModule extends ClientModule {
    public final BooleanSetting cardinal = addSetting(new BooleanSetting("cardinal", "Show cardinal direction", true));
    public DirectionModule() { super("direction", "Direction", "Visuals", "Compass-direction HUD option"); }
}

package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
/** Fullbright UI module placeholder; rendering hook is deliberately isolated for mapping compatibility. */
public final class FullbrightModule extends ClientModule {
    public final BooleanSetting enabledHint = addSetting(new BooleanSetting("bright_hint", "Enable bright-light mode", true));
    public FullbrightModule() { super("fullbright", "Fullbright", "Visuals", "Bright-light display option"); }
}

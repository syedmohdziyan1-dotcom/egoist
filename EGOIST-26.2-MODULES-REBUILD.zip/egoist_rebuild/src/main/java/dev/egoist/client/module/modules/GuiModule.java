package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
import dev.egoist.client.settings.NumberSetting;
public final class GuiModule extends ClientModule {
    public final BooleanSetting blur = addSetting(new BooleanSetting("blur", "Blur background", false));
    public final NumberSetting scale = addSetting(new NumberSetting("scale", "GUI scale factor", 1.0, 0.75, 1.5, 0.05));
    public GuiModule() { super("gui_options", "GUI Options", "GUI", "Client interface options"); }
}

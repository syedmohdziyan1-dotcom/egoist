package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
public final class ChatTimestampModule extends ClientModule {
    public final BooleanSetting seconds = addSetting(new BooleanSetting("seconds", "Include seconds", false));
    public ChatTimestampModule() { super("chat_timestamp", "Chat Timestamp", "Misc", "Timestamp display option for chat"); }
}

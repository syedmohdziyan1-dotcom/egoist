package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
public final class ArmorStatusModule extends ClientModule {
    public final BooleanSetting durability = addSetting(new BooleanSetting("durability", "Show durability values", true));
    public ArmorStatusModule() { super("armor_status", "Armor Status", "Visuals", "Armor-status HUD option"); }
}

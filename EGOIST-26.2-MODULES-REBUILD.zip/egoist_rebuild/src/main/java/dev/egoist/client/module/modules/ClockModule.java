package dev.egoist.client.module.modules;
import dev.egoist.client.module.ClientModule;
import dev.egoist.client.settings.BooleanSetting;
public final class ClockModule extends ClientModule {
    public final BooleanSetting gameTime = addSetting(new BooleanSetting("game_time", "Show in-game time", true));
    public ClockModule() { super("clock", "Clock", "Visuals", "In-game time HUD option"); }
}

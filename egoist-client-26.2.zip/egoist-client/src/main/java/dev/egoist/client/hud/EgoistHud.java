package dev.egoist.client.hud;

import dev.egoist.client.module.ModuleRegistry;
import dev.egoist.client.module.modules.CoordinatesModule;
import dev.egoist.client.module.modules.FpsDisplayModule;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

/** HUD elements for the FPS and coordinate display modules. */
public final class EgoistHud {
    private EgoistHud() {}
    public static void init() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("egoist", "fps_display"), EgoistHud::drawFps);
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("egoist", "coordinates"), EgoistHud::drawCoordinates);
    }
    private static void drawFps(GuiGraphicsExtractor graphics, net.minecraft.client.DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        FpsDisplayModule module = ModuleRegistry.find("fps_display").filter(FpsDisplayModule.class::isInstance).map(FpsDisplayModule.class::cast).orElse(null);
        if (module == null || !module.enabled() || client.player == null || client.gui.screen() != null) return;
        String text = module.showLabel.value() ? "FPS: " + client.getFps() : Integer.toString(client.getFps());
        graphics.text(client.font, text, module.x.value().intValue(), module.y.value().intValue(), 0xFFE8D6FF, true);
    }
    private static void drawCoordinates(GuiGraphicsExtractor graphics, net.minecraft.client.DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        CoordinatesModule module = ModuleRegistry.find("coordinates").filter(CoordinatesModule.class::isInstance).map(CoordinatesModule.class::cast).orElse(null);
        if (module == null || !module.enabled() || client.player == null || client.gui.screen() != null) return;
        String text = String.format(java.util.Locale.ROOT, "XYZ: %.1f, %.1f, %.1f", client.player.getX(), client.player.getY(), client.player.getZ());
        if (module.showFacing.value()) text += "  " + client.player.getDirection().getName().toUpperCase(java.util.Locale.ROOT);
        if (module.showDimension.value() && client.level != null) text += "  " + client.level.dimension().identifier().toString();
        graphics.text(client.font, text, module.x.value().intValue(), module.y.value().intValue(), 0xFFE8D6FF, true);
    }
}

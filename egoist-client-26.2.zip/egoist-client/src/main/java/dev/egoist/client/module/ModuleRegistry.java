package dev.egoist.client.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import dev.egoist.client.module.modules.ToggleSprintModule;
import dev.egoist.client.module.modules.FpsDisplayModule;
import dev.egoist.client.module.modules.CoordinatesModule;
import java.util.HashSet;
import java.util.Set;
import org.lwjgl.glfw.GLFW;

public final class ModuleRegistry {
    private static final List<ClientModule> MODULES = new ArrayList<>();
    private static boolean initialized;
    private static final Set<Integer> keysDown = new HashSet<>();
    private ModuleRegistry() {}
    public static void init() {
        if (initialized) return;
        initialized=true;
        register(new ToggleSprintModule());
        register(new FpsDisplayModule());
        register(new CoordinatesModule());
    }
    public static void register(ClientModule module) {
        if (MODULES.stream().anyMatch(m -> m.id().equalsIgnoreCase(module.id()))) throw new IllegalArgumentException("Duplicate module id: " + module.id());
        MODULES.add(module);
    }
    public static List<ClientModule> all() { return List.copyOf(MODULES); }
    public static List<ClientModule> category(String category) { return MODULES.stream().filter(m -> m.category().equalsIgnoreCase(category)).toList(); }
    public static Optional<ClientModule> find(String id) { return MODULES.stream().filter(m -> m.id().equalsIgnoreCase(id)).findFirst(); }
    public static void tick(Minecraft client) {
        if (client.getWindow() != null && client.gui.screen() == null) {
            long window = client.getWindow().getWindow();
            for (ClientModule module : MODULES) {
                int key = module.keybind();
                if (key <= 0) continue;
                boolean pressed = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
                if (pressed && !keysDown.contains(key)) {
                    try { module.toggle(); } catch (RuntimeException e) { System.err.println("[Egoist] Key toggle failed: " + e.getMessage()); }
                }
                if (pressed) keysDown.add(key); else keysDown.remove(key);
            }
        }
        for (ClientModule module : MODULES) if (module.enabled()) try { module.tick(client); } catch (RuntimeException e) { System.err.println("[Egoist] Module " + module.id() + " tick failed: " + e.getMessage()); module.setEnabled(false); }
    }
}

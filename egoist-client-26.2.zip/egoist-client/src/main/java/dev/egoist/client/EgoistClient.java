package dev.egoist.client;

import dev.egoist.client.config.ConfigManager;
import dev.egoist.client.gui.EgoistScreen;
import dev.egoist.client.hud.EgoistHud;
import dev.egoist.client.hud.EgoistHud;
import dev.egoist.client.module.ModuleRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class EgoistClient implements ClientModInitializer {
    public static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("egoist", "main"));
    private static KeyMapping openGui;
    @Override public void onInitializeClient() {
        ModuleRegistry.init();
        EgoistHud.register();
        ConfigManager.init(net.minecraft.client.Minecraft.getInstance());
        openGui = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.egoist.open_gui", GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.consumeClick()) {
                if (client.gui.screen() == null) client.gui.setScreen(new EgoistScreen());
                else if (client.gui.screen() instanceof EgoistScreen) client.gui.setScreen(null);
            }
            ModuleRegistry.tick(client);
        });
    }
}
